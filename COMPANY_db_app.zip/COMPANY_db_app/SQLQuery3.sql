﻿--select * from work_items

--SELECT Id FROM projects
--SELECT CONCAT(FirstName,' ',LastName) FROM employees

SELECT * FROM project_cooperation


--select * from employees
----SELECT * from teams
--SELECT * from projects

----DELETE FROM teams where id = 8
--SELECT * FROM projects WHERE lower(Name) like '%Cde%' or lower(ProjectManager_ID) like '%2%'


--delete from employees where id >= 11 and id <= 21

--INSERT INTO teams values ('Team 4')
--DELETE FROM teams where id = 4 

--USE [C:\USERS\USER\SOURCE\REPOS\COMPANY_DB_APP\COMPANY_DB_APP\COMPANY_DB_APP\BIN\DEBUG\DB_COMPANY.MDF]
--GO
--INSERT INTO [dbo].[employees]
--           ([FirstName]
--           ,[Middlename]
--           ,[LastName]
--           ,[Email]
--           ,[Team_Id])
--     VALUES
--           ('Prz'
--           ,NULL
--           ,'Prz'
--           ,'Prz'
--           ,2)
--GO

